extern BOOL useAlderis(void);
extern void loadColorPicker(void);
extern UIColor* colorFromHex(NSString* hex);