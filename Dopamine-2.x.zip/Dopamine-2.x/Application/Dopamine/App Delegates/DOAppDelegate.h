//
//  AppDelegate.h
//  Dopamine
//
//  Created by Lars Fröder on 23.09.23.
//

#import <UIKit/UIKit.h>

@interface DOAppDelegate : UIResponder <UIApplicationDelegate>


@end

