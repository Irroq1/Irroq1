//
//  DOUpdateCircleView.h
//  Dopamine
//
//  Created by tomt000 on 06/02/2024.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DOUpdateCircleView : UIView

@property (nonatomic, assign) float progress;

@end

NS_ASSUME_NONNULL_END
