//
//  DOCreditsViewController.h
//  Dopamine
//
//  Created by tomt000 on 08/01/2024.
//

#import <UIKit/UIKit.h>
#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>
#import "DOPSListController.h"

NS_ASSUME_NONNULL_BEGIN

@interface DOCreditsViewController : DOPSListController

@end

NS_ASSUME_NONNULL_END
